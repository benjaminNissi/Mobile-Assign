import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        double salary = 200000, hourlyRate = 1000, netSalary, hoursWorked, reduction;

        String employeeName;

        String empType;

        System.out.println ("Enter employee's name");

        employeeName = in.nextLine();

        System.out.println ("Enter type A (Monthly) , B (Weekly) , C (Hourly)");

        empType = in.nextLine();

        if (empType.equals("A") || empType.equals("a")){

            reduction = (salary * 0.3) + (salary * 0.03);

            netSalary = salary - reduction;

            System.out.println("Names : " + employeeName);
            System.out.println("\n Type : " + empType);
            System.out.println("\n Net Salary: " + netSalary);


        }else if (empType.equals("B") || empType.equals("b")){

            reduction = (salary * 0.03);

            netSalary = salary - reduction;

            System.out.println("Names : " + employeeName);
            System.out.println("\n Type : " + empType);
            System.out.println("\n Net Salary : " + netSalary);

        }else{

            System.out.println ("Number of hours per week");

            hoursWorked = Double.parseDouble(in.nextLine());

            netSalary = hourlyRate * hoursWorked;

            System.out.println("Names : " + employeeName);
            System.out.println("\nType : " + empType);
            System.out.println("\nNet salary : " + netSalary);

        }

    }
}
